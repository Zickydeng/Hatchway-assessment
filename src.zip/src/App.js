import React from 'react';
import Student from './Students'
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Student/>
      </header>
    </div>
  );
}

export default App;
